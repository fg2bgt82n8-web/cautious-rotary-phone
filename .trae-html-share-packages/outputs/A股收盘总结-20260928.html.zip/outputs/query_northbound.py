import sys
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
import json
from call import call

# 尝试用新闻接口查询北向资金
print('Querying northbound news...')
try:
    res = call('news', 'search_news', {
        'query': '北向资金 净买入 2026-09-30',
        'limit': 5
    })
    print(json.dumps(res, ensure_ascii=False, indent=2))
except Exception as e:
    print('Error:', e)
