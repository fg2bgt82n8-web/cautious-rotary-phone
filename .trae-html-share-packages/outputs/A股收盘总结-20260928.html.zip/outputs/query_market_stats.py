import sys
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
import json
from call import call

# 尝试查询09-28市场涨跌家数
print('Querying market stats for 2026-09-28...')

# 方法1: 用sector_data
res1 = call('index', 'sector_data', {
    'query': 'A股市场 2026-09-28 上涨家数、下跌家数、涨停家数、跌停家数'
})
print('sector_data:', json.dumps(res1, ensure_ascii=False, indent=2)[:1000])

# 方法2: 用search_stocks
res2 = call('stock', 'search_stocks', {
    'query': '2026年9月28日 A股上涨股票数量和下跌股票数量'
})
print('search_stocks:', json.dumps(res2, ensure_ascii=False, indent=2)[:1000])
