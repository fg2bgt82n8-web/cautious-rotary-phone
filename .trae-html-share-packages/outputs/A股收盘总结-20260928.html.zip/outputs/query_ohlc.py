import sys
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
import json
from call import call

# 查询2026-09-28的OHLC
print('Querying OHLC for 2026-09-28...')
res = call('stock', 'get_stock_performance', {
    'query': '宇通客车、若羽臣、东鹏饮料、科沃斯、吉比特、中际联合、九号公司 2026-09-28的开盘价、最高价、最低价、收盘价'
})
print(json.dumps(res, ensure_ascii=False, indent=2))
