import sys
import json
import time
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
from call import call
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Try to get northbound total flow
queries = [
    "北向资金 2026-09-28净流入额",
    "陆股通 2026-09-28净买入",
    "上证指数 2026-09-28上涨家数,下跌家数,涨停家数,跌停家数",
    "A股 2026-09-28两市成交额"
]
results = {}
for q in queries:
    res = call("stock", "get_stock_performance", {"query": q})
    results[q] = res
    time.sleep(1.3)

with open('/workspace/outputs/market2_data.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print("Done")
