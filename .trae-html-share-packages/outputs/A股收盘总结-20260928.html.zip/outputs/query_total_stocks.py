import sys
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
import json
from call import call

# 查询A股总数和09-28涨跌家数
print('Querying total A stocks...')
res = call('stock', 'search_stocks', {
    'query': 'A股市场全部股票数量'
})
print(json.dumps(res, ensure_ascii=False, indent=2)[:500])

# 查询上涨家数和下跌家数
print('Querying rise/fall count...')
res2 = call('index', 'sector_data', {
    'query': '全部A股 2026-09-28 上涨股票数量、下跌股票数量、平盘股票数量、涨停股票数量、跌停股票数量'
})
print(json.dumps(res2, ensure_ascii=False, indent=2))
