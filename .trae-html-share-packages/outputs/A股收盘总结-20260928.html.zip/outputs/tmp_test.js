const { call } = require('/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data/call-node.js');

async function main() {
  try {
    const res = await call("stock", "stock_highfreq_quotes", {
      symbols: "600066.SH",
      indicators: "最新价,涨跌幅,成交量,成交额,换手率",
      data_mode: "real_time"
    });
    console.log(JSON.stringify(res, null, 2));
  } catch (e) {
    console.error('Error:', e.message);
  }
}

main();
