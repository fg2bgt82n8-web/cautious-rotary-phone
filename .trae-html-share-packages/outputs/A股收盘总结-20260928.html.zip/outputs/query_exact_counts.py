import sys
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
import json
from call import call

# 查询精确涨跌家数
print('Querying exact rise/fall counts...')
res = call('index', 'sector_data', {
    'query': '上证指数、深证成指 2026-09-28 上涨家数、下跌家数、平盘家数'
})
print(json.dumps(res, ensure_ascii=False, indent=2))
