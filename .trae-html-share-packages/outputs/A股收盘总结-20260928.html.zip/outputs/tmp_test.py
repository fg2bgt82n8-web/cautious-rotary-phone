import sys
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
from call import call

res = call("stock", "stock_highfreq_quotes", {
    "symbols": "600066.SH",
    "indicators": "最新价,涨跌幅,成交量,成交额,换手率",
    "data_mode": "real_time"
})
print(res)
