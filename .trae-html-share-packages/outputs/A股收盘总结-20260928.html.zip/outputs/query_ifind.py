import sys
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
import json
import time
from call import call

results = {}

# 1. 查询7只A股实时行情
print('Querying stocks...')
stock_res = call('stock', 'stock_highfreq_quotes', {
    'symbols': '600066.SH,003010.SZ,605499.SH,603486.SH,603444.SH,605305.SH,689009.SH',
    'indicators': '最新价,涨跌幅,成交量,成交额,换手率,最高价,最低价,开盘价',
    'data_mode': 'real_time'
})
results['stocks'] = stock_res
print('Stocks done:', json.dumps(stock_res, ensure_ascii=False, indent=2)[:500])

time.sleep(1.5)

# 2. 查询大盘指数
print('Querying indices...')
index_res = call('index', 'index_highfreq_quotes', {
    'symbols': '000001.SH,399001.SZ,399006.SZ,000300.SH,000688.SH',
    'indicators': '最新价,涨跌幅,成交额,成交量,上涨家数,下跌家数,涨停家数,跌停家数',
    'data_mode': 'real_time'
})
results['indices'] = index_res
print('Indices done:', json.dumps(index_res, ensure_ascii=False, indent=2)[:500])

time.sleep(1.5)

# 3. 尝试通过新闻查询北向资金（如果上述接口没有）
# 先保存当前结果
with open('/workspace/outputs/ifind_data.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print('Data saved to /workspace/outputs/ifind_data.json')
