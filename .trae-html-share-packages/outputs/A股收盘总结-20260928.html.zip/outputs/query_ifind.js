const { call } = require('/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data/call-node.js');
const fs = require('fs');

function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function main() {
    const results = {};

    // 1. 查询7只A股实时行情
    console.log('Querying stocks...');
    const stockRes = await call('stock', 'stock_highfreq_quotes', {
        symbols: '600066.SH,003010.SZ,605499.SH,603486.SH,603444.SH,605305.SH,689009.SH',
        indicators: '最新价,涨跌幅,成交量,成交额,换手率,最高价,最低价,开盘价',
        data_mode: 'real_time'
    });
    results.stocks = stockRes;
    console.log('Stocks done');

    await sleep(1500);

    // 2. 查询大盘指数
    console.log('Querying indices...');
    const indexRes = await call('index', 'index_highfreq_quotes', {
        symbols: '000001.SH,399001.SZ,399006.SZ,000300.SH,000688.SH',
        indicators: '最新价,涨跌幅,成交额,成交量,上涨家数,下跌家数,涨停家数,跌停家数',
        data_mode: 'real_time'
    });
    results.indices = indexRes;
    console.log('Indices done');

    await sleep(1500);

    // 3. 尝试查询北向资金（通过新闻或特定接口可能不存在，先尝试）
    // 北向资金可能在 stock 服务的某个工具中，先尝试 get_stock_performance 或查询特定指标
    console.log('Querying northbound...');
    try {
        const northRes = await call('stock', 'stock_highfreq_quotes', {
            symbols: '000001.SH',
            indicators: '最新价',
            data_mode: 'real_time'
        });
        results.northbound = northRes;
    } catch (e) {
        results.northbound = { error: e.message };
    }

    fs.writeFileSync('/workspace/outputs/ifind_data.json', JSON.stringify(results, null, 2), 'utf-8');
    console.log('All data saved to /workspace/outputs/ifind_data.json');
}

main().catch(err => {
    console.error(err);
    process.exit(1);
});
