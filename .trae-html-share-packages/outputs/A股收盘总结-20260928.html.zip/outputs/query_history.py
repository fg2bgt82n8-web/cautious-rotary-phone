import sys
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
import json
from call import call

# 尝试查询2026-09-28的日频行情
print('Querying 2026-09-28 stock performance...')
stock_res = call('stock', 'get_stock_performance', {
    'query': '宇通客车、若羽臣、东鹏饮料、科沃斯、吉比特、中际联合、九号公司 2026-09-28的收盘价、涨跌幅、成交量、成交额、换手率'
})
print(json.dumps(stock_res, ensure_ascii=False, indent=2)[:1000])
