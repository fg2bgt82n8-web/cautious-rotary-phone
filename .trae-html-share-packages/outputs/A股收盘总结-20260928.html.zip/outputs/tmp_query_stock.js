const { call } = require('/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data/call-node.js');
const fs = require('fs');

const stocks = [
  "600066.SH", "003010.SZ", "605499.SH", "603486.SH",
  "603444.SH", "605305.SH", "689009.SH"
];

async function main() {
  const results = [];
  for (const stock of stocks) {
    try {
      const res = await call("stock", "get_stock_performance", {
        query: `${stock} 2026-09-28的收盘价,涨跌幅,成交量,成交额,换手率`
      });
      results.push({ stock, data: res });
    } catch (e) {
      results.push({ stock, error: e.message });
    }
    await new Promise(r => setTimeout(r, 1300));
  }
  fs.writeFileSync('/workspace/outputs/stock_data.json', JSON.stringify(results, null, 2));
  console.log('stock data saved');
}

main().catch(console.error);
