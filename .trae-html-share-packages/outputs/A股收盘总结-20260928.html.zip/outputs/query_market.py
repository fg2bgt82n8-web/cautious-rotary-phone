import sys
import json
import time
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
from call import call
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 1. Index data for 2026-09-28
indices = ["上证指数", "深证成指", "创业板指", "沪深300", "科创50"]
index_results = {}
for idx in indices:
    res = call("index", "index_data", {
        "query": f"{idx} 2026-09-28的收盘价和涨跌幅"
    })
    index_results[idx] = res
    time.sleep(1.3)

with open('/workspace/outputs/index_data.json', 'w', encoding='utf-8') as f:
    json.dump(index_results, f, ensure_ascii=False, indent=2)

# 2. Market stats via real-time (latest available)
rt_index = call("index", "index_highfreq_quotes", {
    "symbols": "000001.SH,399001.SZ,399006.SZ,000300.SH,000688.SH",
    "indicators": "最新价,涨跌幅,成交额,成交量,上涨家数,下跌家数,涨停家数,跌停家数",
    "data_mode": "real_time"
})

with open('/workspace/outputs/rt_index_data.json', 'w', encoding='utf-8') as f:
    json.dump(rt_index, f, ensure_ascii=False, indent=2)

# 3. Northbound capital (try various queries)
north_queries = [
    "北向资金 2026-09-28净买入",
    "沪股通 2026-09-28资金净流入",
    "深股通 2026-09-28资金净流入"
]
north_results = []
for q in north_queries:
    res = call("stock", "get_stock_performance", {"query": q})
    north_results.append({"query": q, "result": res})
    time.sleep(1.3)

with open('/workspace/outputs/north_data.json', 'w', encoding='utf-8') as f:
    json.dump(north_results, f, ensure_ascii=False, indent=2)

print("Market queries done")
