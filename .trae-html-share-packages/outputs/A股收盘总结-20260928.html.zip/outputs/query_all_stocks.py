import sys
import json
import time
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
from call import call
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

stocks = [
    "600066.SH", "003010.SZ", "605499.SH", "603486.SH",
    "603444.SH", "605305.SH", "689009.SH"
]

# 1. Real-time quotes
rt_results = {}
for s in stocks:
    res = call("stock", "stock_highfreq_quotes", {
        "symbols": s,
        "indicators": "最新价,涨跌幅,成交量,成交额,换手率,开盘价,最高价,最低价",
        "data_mode": "real_time"
    })
    rt_results[s] = res
    time.sleep(1.3)

with open('/workspace/outputs/rt_stock_data.json', 'w', encoding='utf-8') as f:
    json.dump(rt_results, f, ensure_ascii=False, indent=2)

# 2. Historical performance for 2026-09-28
hist_results = {}
for s in stocks:
    res = call("stock", "get_stock_performance", {
        "query": f"{s} 2026-09-28的收盘价,涨跌幅,成交量,成交额,换手率"
    })
    hist_results[s] = res
    time.sleep(1.3)

with open('/workspace/outputs/hist_stock_data.json', 'w', encoding='utf-8') as f:
    json.dump(hist_results, f, ensure_ascii=False, indent=2)

print("All queries done")
