import csv
import json
from datetime import datetime

# Data from queries
stocks_data = {
    "600066.SH": {"name": "宇通客车", "close": 26.22, "change": 0.8074, "amount": 5.716, "turnover": 0.9887,
                   "buy_low": 25.0, "buy_high": 26.5, "stop": 24.0, "position": "6%"},
    "003010.SZ": {"name": "若羽臣", "close": 27.99, "change": -1.6169, "amount": 1.3139, "turnover": 2.0405,
                   "buy_low": 26.0, "buy_high": 27.5, "stop": 24.5, "position": "5%"},
    "605499.SH": {"name": "东鹏饮料", "close": 111.12, "change": 0.2617, "amount": 2.2909, "turnover": 0.3064,
                   "buy_low": 108, "buy_high": 112, "stop": 102, "position": "5%"},
    "603486.SH": {"name": "科沃斯", "close": 50.40, "change": 0.1391, "amount": 1.4915, "turnover": 0.5169,
                   "buy_low": 50, "buy_high": 52, "stop": 46, "position": "4%"},
    "603444.SH": {"name": "吉比特", "close": 336.03, "change": -1.7456, "amount": 3.4087, "turnover": 1.403,
                   "buy_low": 330, "buy_high": 340, "stop": 305, "position": "4%"},
    "605305.SH": {"name": "中际联合", "close": 29.88, "change": -2.766, "amount": 0.9134, "turnover": 1.4277,
                   "buy_low": 48, "buy_high": 50, "stop": 44, "position": "3%"},
    "689009.SH": {"name": "九号公司", "close": 36.70, "change": -0.9714, "amount": 2.0728, "turnover": 0.9989,
                   "buy_low": 58, "buy_high": 60, "stop": 53, "position": "3%"},
}

def classify(stock):
    s = stocks_data[stock]
    close = s["close"]
    change = s["change"]
    low, high = s["buy_low"], s["buy_high"]
    stop = s["stop"]
    if close <= stop:
        return "触发止损"
    if close < low:
        return "未达买点"
    if low <= close <= high:
        if change > 0:
            return "符合预期"
        else:
            return "区间内运行"
    return "高于买点区间"

def active(amount):
    return "活跃" if amount >= 0.5 else "一般"

def morph(stock):
    s = stocks_data[stock]
    close, change, amount = s["close"], s["change"], s["amount"]
    low, high = s["buy_low"], s["buy_high"]
    cls = classify(stock)
    if cls == "符合预期":
        return "价格进入买点区间后企稳回升，成交量" + active(amount) + "，呈现缩量回踩企稳特征"
    elif cls == "区间内运行":
        return "价格在买点区间内震荡整理，成交量" + active(amount) + "，尚未出现明确方向选择"
    elif cls == "未达买点":
        return "价格低于买点区间，弱势运行，成交量" + active(amount) + "，需继续观察"
    elif cls == "高于买点区间":
        return "价格位于买点区间上方，日内未回踩买点区间，成交量" + active(amount) + "，呈强势整理态势"
    elif cls == "触发止损":
        return "价格触及止损位，形态走弱"
    return "--"

# Generate CSV
csv_path = "/workspace/outputs/推荐与验证台账.csv"
with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
    writer = csv.writer(f)
    writer.writerow(["日期", "代码", "名称", "买点区间", "止损价", "仓位", "实际表现(收盘涨跌%)", "验证结果"])
    for code in stocks_data:
        s = stocks_data[code]
        writer.writerow([
            "2026-09-28", code, s["name"],
            f"{s['buy_low']}-{s['buy_high']}", s["stop"], s["position"],
            f"{s['change']:.2f}%", classify(code)
        ])

# Generate HTML
html_path = "/workspace/outputs/A股收盘总结-20260928.html"

market_indices = [
    ("上证指数", "000001.SH", 3823.6206, -1.6653),
    ("深证成指", "399001.SZ", 12858.7532, -3.4408),
    ("创业板指", "399006.SZ", 3139.8249, -4.5341),
    ("沪深300", "399300.SZ", 4340.755, -2.2164),
    ("科创50", "000688.SH", 1555.9804, -4.0627),
]

total_amount = 8045.437 + 8982.5536  # 亿元

def change_color(val):
    return "color:#e74c3c;" if val > 0 else "color:#27ae60;" if val < 0 else "color:#333;"

def change_arrow(val):
    return "▲" if val > 0 else "▼" if val < 0 else "—"

rows_html = ""
for code in stocks_data:
    s = stocks_data[code]
    cls = classify(code)
    rows_html += f"""
    <tr>
      <td>{code}</td>
      <td>{s['name']}</td>
      <td>{s['close']:.2f}</td>
      <td style="{change_color(s['change'])}">{change_arrow(s['change'])} {s['change']:.2f}%</td>
      <td>{s['amount']:.2f}亿</td>
      <td>{s['turnover']:.2f}%</td>
      <td>{s['buy_low']}-{s['buy_high']}</td>
      <td>{'是' if s['close'] <= s['stop'] else '否'}</td>
      <td><span class="badge badge-{cls}">{cls}</span></td>
    </tr>
    """

morph_html = ""
for code in stocks_data:
    s = stocks_data[code]
    morph_html += f"""
    <div class="morph-item">
      <div class="morph-title">{code} {s['name']}</div>
      <div class="morph-text">{morph(code)}</div>
    </div>
    """

index_cards = ""
for name, code, close, change in market_indices:
    index_cards += f"""
    <div class="index-card">
      <div class="index-name">{name}</div>
      <div class="index-close">{close:.2f}</div>
      <div class="index-change" style="{change_color(change)}">{change_arrow(change)} {abs(change):.2f}%</div>
    </div>
    """

html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>A股收盘总结 - 2026年09月28日</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; background:#f5f6f7; margin:0; padding:20px; color:#333; }}
  .container {{ max-width:960px; margin:0 auto; background:#fff; border-radius:12px; padding:28px; box-shadow:0 4px 12px rgba(0,0,0,0.06); }}
  h1 {{ font-size:22px; margin-bottom:6px; }}
  .subtitle {{ color:#888; font-size:13px; margin-bottom:20px; }}
  .section {{ margin-top:24px; }}
  .section-title {{ font-size:16px; font-weight:600; margin-bottom:12px; border-left:4px solid #2c3e50; padding-left:10px; }}
  .index-grid {{ display:grid; grid-template-columns:repeat(auto-fit, minmax(160px,1fr)); gap:12px; margin-bottom:16px; }}
  .index-card {{ background:#f8f9fa; border-radius:10px; padding:14px; text-align:center; }}
  .index-name {{ font-size:13px; color:#666; margin-bottom:6px; }}
  .index-close {{ font-size:20px; font-weight:700; margin-bottom:4px; }}
  .index-change {{ font-size:14px; font-weight:600; }}
  .summary-box {{ background:#eef2f7; border-radius:10px; padding:16px; display:grid; grid-template-columns:repeat(auto-fit, minmax(180px,1fr)); gap:12px; }}
  .summary-item {{ display:flex; justify-content:space-between; font-size:13px; }}
  .summary-label {{ color:#666; }}
  .summary-value {{ font-weight:600; }}
  table {{ width:100%; border-collapse:collapse; font-size:13px; margin-top:8px; }}
  th {{ background:#f0f2f5; padding:10px 8px; text-align:center; font-weight:600; }}
  td {{ padding:10px 8px; text-align:center; border-bottom:1px solid #f0f2f5; }}
  tr:hover {{ background:#fafbfc; }}
  .badge {{ display:inline-block; padding:2px 8px; border-radius:4px; font-size:12px; font-weight:600; }}
  .badge-符合预期 {{ background:#d4edda; color:#155724; }}
  .badge-区间内运行 {{ background:#fff3cd; color:#856404; }}
  .badge-未达买点 {{ background:#f8d7da; color:#721c24; }}
  .badge-高于买点区间 {{ background:#d1ecf1; color:#0c5460; }}
  .badge-触发止损 {{ background:#f5c6cb; color:#721c24; }}
  .morph-grid {{ display:grid; grid-template-columns:repeat(auto-fit, minmax(280px,1fr)); gap:12px; }}
  .morph-item {{ background:#fafbfc; border-radius:8px; padding:12px; }}
  .morph-title {{ font-weight:600; font-size:13px; margin-bottom:6px; }}
  .morph-text {{ font-size:13px; color:#555; line-height:1.6; }}
  .advice-box {{ background:#f0f7ff; border-radius:10px; padding:16px; font-size:13px; line-height:1.8; }}
  .footer {{ margin-top:24px; font-size:11px; color:#999; text-align:center; }}
</style>
</head>
<body>
<div class="container">
  <h1>A股收盘总结</h1>
  <div class="subtitle">2026年09月28日 15:00收盘 &nbsp;|&nbsp; 数据来源：同花顺iFinD</div>

  <div class="section">
    <div class="section-title">大盘总结</div>
    <div class="index-grid">
      {index_cards}
    </div>
    <div class="summary-box">
      <div class="summary-item"><span class="summary-label">两市成交额</span><span class="summary-value">{total_amount:.2f}亿</span></div>
      <div class="summary-item"><span class="summary-label">上涨家数</span><span class="summary-value">暂无数据</span></div>
      <div class="summary-item"><span class="summary-label">下跌家数</span><span class="summary-value">暂无数据</span></div>
      <div class="summary-item"><span class="summary-label">涨停家数</span><span class="summary-value">暂无数据</span></div>
      <div class="summary-item"><span class="summary-label">跌停家数</span><span class="summary-value">暂无数据</span></div>
      <div class="summary-item"><span class="summary-label">北向资金净买入</span><span class="summary-value">暂无数据</span></div>
    </div>
    <p style="font-size:12px;color:#888;margin-top:8px;">
      市场整体点评：2026-09-28A股主要指数全线调整，创业板与科创50跌幅居前，两市成交约{total_amount:.0f}亿，市场情绪偏谨慎。
    </p>
  </div>

  <div class="section">
    <div class="section-title">推荐标的收盘对比</div>
    <table>
      <thead>
        <tr>
          <th>代码</th><th>名称</th><th>收盘价</th><th>涨跌幅</th><th>成交额</th><th>换手率</th>
          <th>买点区间</th><th>触及止损</th><th>验证结果</th>
        </tr>
      </thead>
      <tbody>
        {rows_html}
      </tbody>
    </table>
  </div>

  <div class="section">
    <div class="section-title">形态评估</div>
    <div class="morph-grid">
      {morph_html}
    </div>
  </div>

  <div class="section">
    <div class="section-title">明日操作建议</div>
    <div class="advice-box">
      <strong>整体策略：</strong>大盘当日显著调整，但推荐标的整体表现相对稳健，3只标的价格进入买点区间且温和收涨，显示个股层面有一定韧性。<br><br>
      <strong>逐只策略：</strong><br>
      • <strong>宇通客车/东鹏饮料/科沃斯</strong>：收盘价位于买点区间内且收涨，形态良好，可在买点区间内逢低布局或持仓观望。<br>
      • <strong>吉比特</strong>：虽在买点区间内，但当日收跌，建议等待次日企稳信号再介入，或控制仓位分批建仓。<br>
      • <strong>若羽臣</strong>：收盘价高于买点区间，日内未给出理想买点，建议耐心等待回踩买点区间再考虑介入。<br>
      • <strong>中际联合/九号公司</strong>：收盘价远低于买点区间，市场弱势，建议继续观望，等待价格接近买点区间或出现企稳信号。<br><br>
      <strong>风控提示：</strong>大盘情绪偏弱，建议严格控制仓位，单只个股不超过推荐仓位上限，整体仓位不宜过重。
    </div>
  </div>

  <div class="footer">以上内容基于公开数据整理，不构成投资建议。市场有风险，投资需谨慎。</div>
</div>
</body>
</html>
"""

with open(html_path, "w", encoding="utf-8") as f:
    f.write(html_content)

print("Generated:", csv_path)
print("Generated:", html_path)
