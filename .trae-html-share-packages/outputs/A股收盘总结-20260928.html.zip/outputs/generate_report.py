import json
import csv
from datetime import datetime

# 数据整理
stocks_data = [
    {"code": "600066.SH", "name": "宇通客车", "buy_low": 25.0, "buy_high": 26.5, "stop": 24.0, "position": "6%",
     "close": 26.22, "change": 0.8074, "amount": 5.716, "turnover": 0.9887,
     "open": 25.97, "high": 26.40, "low": 25.75},
    {"code": "003010.SZ", "name": "若羽臣", "buy_low": 26.0, "buy_high": 27.5, "stop": 24.5, "position": "5%",
     "close": 27.99, "change": -1.6169, "amount": 1.3139, "turnover": 2.0405,
     "open": 28.50, "high": 29.15, "low": 27.88},
    {"code": "605499.SH", "name": "东鹏饮料", "buy_low": 108, "buy_high": 112, "stop": 102, "position": "5%",
     "close": 111.12, "change": 0.2617, "amount": 2.2909, "turnover": 0.3064,
     "open": 111.17, "high": 111.59, "low": 109.68},
    {"code": "603486.SH", "name": "科沃斯", "buy_low": 50, "buy_high": 52, "stop": 46, "position": "4%",
     "close": 50.40, "change": 0.1391, "amount": 1.4915, "turnover": 0.5169,
     "open": 50.50, "high": 51.00, "low": 49.71},
    {"code": "603444.SH", "name": "吉比特", "buy_low": 330, "buy_high": 340, "stop": 305, "position": "4%",
     "close": 336.03, "change": -1.7456, "amount": 3.4087, "turnover": 1.403,
     "open": 343.04, "high": 343.04, "low": 333.00},
    {"code": "605305.SH", "name": "中际联合", "buy_low": 48, "buy_high": 50, "stop": 44, "position": "3%",
     "close": 29.88, "change": -2.766, "amount": 0.9134, "turnover": 1.4277,
     "open": 30.68, "high": 30.73, "low": 29.88},
    {"code": "689009.SH", "name": "九号公司", "buy_low": 58, "buy_high": 60, "stop": 53, "position": "3%",
     "close": 36.70, "change": -0.9714, "amount": 2.0728, "turnover": 0.9989,
     "open": 37.08, "high": 37.43, "low": 36.61},
]

# 计算验证结果和买点位置
def evaluate(s):
    if s["close"] < s["stop"]:
        s["result"] = "触发止损"
        s["buy_pos"] = "止损下方"
    elif s["close"] < s["buy_low"]:
        s["result"] = "未达买点"
        s["buy_pos"] = "买点下方"
    elif s["buy_low"] <= s["close"] <= s["buy_high"]:
        s["result"] = "区间内运行"
        s["buy_pos"] = "买点区间内"
    else:
        s["result"] = "符合预期"
        s["buy_pos"] = "买点上方"
    return s

for s in stocks_data:
    evaluate(s)

# 形态评估
def pattern_eval(s):
    name = s["name"]
    if name == "宇通客车":
        return "开盘25.97即处于买点区间内，盘中最低25.75接近买点下沿后获得支撑，收盘26.22回到区间中上部，日线收阳，呈现缩量企稳迹象。"
    elif name == "若羽臣":
        return "开盘28.50即处于买点上方，盘中一度冲高至29.15，但随后回落，收盘27.99仍高于买点上限，呈现冲高回落态势，需警惕上方抛压。"
    elif name == "东鹏饮料":
        return "开盘111.17处于买点区间内，全天在109.68-111.59窄幅震荡，收盘111.12接近区间上沿，呈现围绕买点中轴缩量整理格局。"
    elif name == "科沃斯":
        return "开盘50.50处于买点区间内，盘中最低49.71短暂跌破买点下限50，但收盘50.40收回区间，呈现缩量回踩买点下沿后小幅回升。"
    elif name == "吉比特":
        return "开盘343.04高于买点区间，但随后持续回落，最低333.00接近买点下限330，收盘336.03回到区间内，呈现高开低走、在买点区间寻求支撑的态势。"
    elif name == "中际联合":
        return "开盘30.68，随后震荡走低，收盘29.88为全天最低，几乎光头光脚阴线，收盘远低于止损价44，空头主导，弱势特征明显。"
    elif name == "九号公司":
        return "开盘37.08，全天在36.61-37.43窄幅波动，收盘36.70，股价远低于止损价53，呈现低位弱势整理格局。"
    return ""

for s in stocks_data:
    s["pattern"] = pattern_eval(s)

# 生成CSV
csv_path = "/workspace/outputs/推荐与验证台账.csv"
with open(csv_path, "w", newline="", encoding="utf-8-sig") as f:
    writer = csv.writer(f)
    writer.writerow(["序号", "市场", "股票代码", "股票名称", "买点区间", "止损价", "仓位比例", "实际表现(收盘涨跌%)", "验证结果"])
    for i, s in enumerate(stocks_data, 1):
        writer.writerow([i, "A股", s["code"], s["name"], f"{s['buy_low']}-{s['buy_high']}", s["stop"], s["position"], round(s["change"], 2), s["result"]])

print(f"CSV已保存: {csv_path}")

# 生成HTML
index_data = {
    "上证指数": {"close": 3823.62, "change": -1.6653, "amount": 8045.44},
    "深证成指": {"close": 12858.75, "change": -3.4408, "amount": 8982.55},
    "创业板指": {"close": 3139.82, "change": -4.5341, "amount": 4332.30},
    "沪深300": {"close": 4340.76, "change": -2.2164, "amount": 4286.20},
    "科创50": {"close": 1555.98, "change": -4.0627, "amount": 805.86},
}

total_amount = index_data["上证指数"]["amount"] + index_data["深证成指"]["amount"]
up_ratio = 16.125
total_stocks = 5575
up_count = int(round(total_stocks * up_ratio / 100))
down_count = total_stocks - up_count
limit_up = 35
limit_down = 60

date_str = "2026-09-28"

def updown_class(change):
    return "up" if change > 0 else "down" if change < 0 else "neutral"

def updown_text(change):
    return f"+{change:.2f}%" if change > 0 else f"{change:.2f}%"

html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<title>A股收盘总结-{date_str}</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif; background: #f5f6f8; color: #1a1a1a; margin: 0; padding: 20px; }}
.container {{ max-width: 960px; margin: 0 auto; }}
h1 {{ text-align: center; font-size: 24px; margin-bottom: 8px; }}
.subtitle {{ text-align: center; color: #666; font-size: 14px; margin-bottom: 24px; }}
.card {{ background: #fff; border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }}
.card-title {{ font-size: 16px; font-weight: 600; margin-bottom: 16px; border-left: 4px solid #2563eb; padding-left: 10px; }}
.market-grid {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: 12px; }}
.market-item {{ background: #f8f9fa; border-radius: 6px; padding: 12px; text-align: center; }}
.market-name {{ font-size: 13px; color: #666; margin-bottom: 4px; }}
.market-value {{ font-size: 20px; font-weight: 600; margin-bottom: 4px; }}
.market-change {{ font-size: 13px; font-weight: 500; }}
.up {{ color: #d93026; }}
.down {{ color: #237a3c; }}
.neutral {{ color: #666; }}
.summary-row {{ display: flex; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-top: 12px; }}
.summary-item {{ flex: 1; min-width: 120px; background: #f8f9fa; border-radius: 6px; padding: 10px; text-align: center; }}
.summary-label {{ font-size: 12px; color: #666; }}
.summary-value {{ font-size: 16px; font-weight: 600; margin-top: 4px; }}
table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
th, td {{ padding: 10px 8px; text-align: center; border-bottom: 1px solid #eee; }}
th {{ background: #f8f9fa; font-weight: 600; color: #333; }}
tr:hover {{ background: #fafafa; }}
.td-left {{ text-align: left; }}
.badge {{ display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 12px; font-weight: 500; }}
.badge-success {{ background: #e6f4ea; color: #1e7e34; }}
.badge-warning {{ background: #fff3cd; color: #856404; }}
.badge-danger {{ background: #fce8e8; color: #c5221f; }}
.badge-info {{ background: #e8f0fe; color: #1967d2; }}
.pattern-text {{ color: #444; line-height: 1.6; font-size: 13px; }}
.advice-box {{ background: #f0f7ff; border-left: 4px solid #2563eb; padding: 12px 16px; border-radius: 0 6px 6px 0; font-size: 13px; line-height: 1.6; }}
.footer {{ text-align: center; color: #999; font-size: 12px; margin-top: 24px; }}
</style>
</head>
<body>
<div class="container">
<h1>A股收盘总结报告</h1>
<div class="subtitle">数据日期：{date_str} | 数据来源：同花顺 iFinD</div>

<!-- 大盘总结卡 -->
<div class="card">
<div class="card-title">大盘总结</div>
<div class="market-grid">
"""

for name, d in index_data.items():
    cls = updown_class(d["change"])
    html += f"""
<div class="market-item">
<div class="market-name">{name}</div>
<div class="market-value">{d['close']:.2f}</div>
<div class="market-change {cls}">{updown_text(d['change'])}</div>
</div>
"""

html += f"""
</div>
<div class="summary-row">
<div class="summary-item">
<div class="summary-label">两市成交额</div>
<div class="summary-value">{total_amount:.0f}亿</div>
</div>
<div class="summary-item">
<div class="summary-label">上涨家数</div>
<div class="summary-value up">~{up_count}家</div>
</div>
<div class="summary-item">
<div class="summary-label">下跌家数</div>
<div class="summary-value down">~{down_count}家</div>
</div>
<div class="summary-item">
<div class="summary-label">涨停/跌停</div>
<div class="summary-value">{limit_up}/{limit_down}</div>
</div>
<div class="summary-item">
<div class="summary-label">北向资金净买入</div>
<div class="summary-value neutral">暂无数据</div>
</div>
</div>
</div>

<!-- 7只A股收盘对比表 -->
<div class="card">
<div class="card-title">推荐标的收盘表现（7只A股）</div>
<table>
<thead>
<tr>
<th>股票代码</th>
<th>股票名称</th>
<th>收盘价</th>
<th>涨跌幅</th>
<th>成交额</th>
<th>换手率</th>
<th>买点位置</th>
<th>验证结果</th>
</tr>
</thead>
<tbody>
"""

for s in stocks_data:
    cls = updown_class(s["change"])
    badge_cls = {
        "符合预期": "badge-success",
        "区间内运行": "badge-info",
        "未达买点": "badge-warning",
        "触发止损": "badge-danger",
    }.get(s["result"], "badge-info")
    html += f"""
<tr>
<td>{s['code']}</td>
<td class="td-left">{s['name']}</td>
<td>{s['close']:.2f}</td>
<td class="{cls}">{updown_text(s['change'])}</td>
<td>{s['amount']:.2f}亿</td>
<td>{s['turnover']:.2f}%</td>
<td>{s['buy_pos']}</td>
<td><span class="badge {badge_cls}">{s['result']}</span></td>
</tr>
"""

html += """
</tbody>
</table>
</div>

<!-- 形态评估 -->
<div class="card">
<div class="card-title">逐只形态评估</div>
"""

for s in stocks_data:
    html += f"""
<div style="margin-bottom:14px;">
<strong>{s['code']} {s['name']}</strong>
<span class="badge {"badge-success" if s['result']=="符合预期" else "badge-info" if s['result']=="区间内运行" else "badge-warning" if s['result']=="未达买点" else "badge-danger"}">{s['result']}</span>
<div class="pattern-text">{s['pattern']}</div>
</div>
"""

html += """
</div>

<!-- 明日操作建议 -->
<div class="card">
<div class="card-title">明日操作建议</div>
<div class="advice-box">
<strong>总体判断：</strong>2026-09-28市场整体偏弱，三大指数集体收跌，创业板指跌幅超4%，两市上涨个股占比仅约16%。在系统性调整背景下，推荐标的多数表现相对稳健。<br><br>
<strong>个股策略：</strong><br>
1. <strong>宇通客车、东鹏饮料、科沃斯</strong>：收盘处于买点区间内，可关注明日能否在买点区间获得支撑并放量突破。若放量突破买点区间上沿，可考虑按计划建仓；若跌破买点区间下沿，建议观望。<br>
2. <strong>若羽臣</strong>：收盘价在买点上方，但当日收跌且呈现冲高回落，建议观察明日能否企稳回升，确认支撑有效后再行介入。<br>
3. <strong>吉比特</strong>：高开低走后回落至买点区间内，需警惕进一步下探买点下限330的风险。若明日能在330附近缩量企稳，可考虑低吸；若放量跌破330，建议暂时回避。<br>
4. <strong>中际联合、九号公司</strong>：收盘价已远低于止损价，处于深度破位状态。严格按照止损纪律，不建议在当前位置补仓或新建仓位，应等待股价重新站稳止损价上方后再评估。<br><br>
<strong>仓位控制：</strong>市场弱势背景下，建议整体仓位控制在30%以内，单只个股仓位不超过计划仓位上限，分批建仓、留足现金应对波动。
</div>
</div>

<div class="footer">以上内容基于公开数据整理，不构成投资建议。数据来源：同花顺 iFinD。</div>
</div>
</body>
</html>
"""

html_path = f"/workspace/outputs/A股收盘总结-{date_str.replace('-', '')}.html"
with open(html_path, "w", encoding="utf-8") as f:
    f.write(html)

print(f"HTML已保存: {html_path}")
