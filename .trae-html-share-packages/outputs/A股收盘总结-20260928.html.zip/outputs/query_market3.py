import sys
import json
import time
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
from call import call
import urllib3
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

queries = [
    "上证指数 2026-09-28成交额",
    "深证成指 2026-09-28成交额",
    "上证指数 2026-09-28成交量",
    "深证成指 2026-09-28成交量"
]
results = {}
for q in queries:
    res = call("index", "index_data", {"query": q})
    results[q] = res
    time.sleep(1.3)

with open('/workspace/outputs/market3_data.json', 'w', encoding='utf-8') as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print("Done")
