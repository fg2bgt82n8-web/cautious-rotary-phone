import sys
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
import json
from call import call

# 查询2026-09-28市场新闻
print('Querying news for 2026-09-28...')
res = call('news', 'search_news', {
    'query': 'A股 北向资金 净买入 涨跌家数 涨停',
    'time_start': '2026-09-28',
    'time_end': '2026-09-28',
    'size': 10
})
print(json.dumps(res, ensure_ascii=False, indent=2))
