import sys
sys.path.insert(0, '/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data')
import json
from call import call

# 查询2026-09-28指数日频数据
print('Querying 2026-09-28 index data...')
index_res = call('index', 'index_data', {
    'query': '上证指数、深证成指、创业板指、沪深300、科创50 2026-09-28的收盘价、涨跌幅、成交额、成交量'
})
print(json.dumps(index_res, ensure_ascii=False, indent=2)[:1500])
