const AUTH_TOKEN = process.env.IFIND_AUTH_TOKEN;
const BASE = "https://api-mcp.51ifind.com:8643/ds-mcp-servers";
const SERVER = `${BASE}/hexin-ifind-ds-index-mcp`;

async function post(payload, sessionId = null, timeout = 30000) {
    const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream',
        'Authorization': AUTH_TOKEN,
    };
    if (sessionId) headers['Mcp-Session-Id'] = sessionId;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);

    try {
        const res = await fetch(SERVER, {
            method: 'POST',
            headers,
            body: JSON.stringify(payload),
            signal: controller.signal,
        });
        clearTimeout(timer);
        const data = await res.json();
        return { res, data, sessionId: res.headers.get('mcp-session-id') };
    } catch (e) {
        clearTimeout(timer);
        throw e;
    }
}

async function main() {
    // initialize
    const initPayload = {
        jsonrpc: "2.0",
        id: 1,
        method: "initialize",
        params: {
            protocolVersion: "2025-03-26",
            capabilities: {},
            clientInfo: { name: "http-client", version: "1.0.0" },
        },
    };
    const { res: initRes, sessionId } = await post(initPayload, null, 30000);
    if (!sessionId) {
        throw new Error("No session id returned");
    }
    console.error("Session ID:", sessionId.slice(0, 10) + "...");

    // notifications/initialized
    await post({ jsonrpc: "2.0", method: "notifications/initialized" }, sessionId, 10000);

    // tools/call index_highfreq_quotes
    const payload = {
        jsonrpc: "2.0",
        id: 2,
        method: "tools/call",
        params: {
            name: "index_highfreq_quotes",
            arguments: {
                symbols: "000001,399001,399006,000300,000688",
                indicators: "最新价,涨跌幅,成交额,上涨家数,下跌家数,涨停家数,跌停家数",
                data_mode: "real_time",
            },
        },
    };
    const { data } = await post(payload, sessionId, 30000);
    console.log(JSON.stringify(data, null, 2));
}

main().catch(e => {
    console.error("Error:", e.message);
    process.exit(1);
});
