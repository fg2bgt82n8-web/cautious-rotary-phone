const { call } = require('/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data/call-node.js');

async function main() {
    const result = await call("stock", "stock_highfreq_quotes", {
        symbols: "600066",
        indicators: "最新价,涨跌幅",
        data_mode: "real_time"
    });
    console.log(JSON.stringify(result, null, 2));
}

main().catch(console.error);
