const { call } = require('/data/user/plugins/trae-remote-official/ifind/1.4.0/skills/ifind-finance-data/call-node.js');

async function main() {
    // 查询7只A股实时行情
    const stocks = await call("stock", "stock_highfreq_quotes", {
        symbols: "600066,003010,605499,603486,603444,605305,689009",
        indicators: "最新价,涨跌幅,成交量,成交额,换手率",
        data_mode: "real_time"
    });
    console.log("===STOCKS===");
    console.log(JSON.stringify(stocks, null, 2));
}

main().catch(console.error);
