const AUTH_TOKEN = process.env.IFIND_AUTH_TOKEN;
const BASE = "https://api-mcp.51ifind.com:8643/ds-mcp-servers";
const SERVER = `${BASE}/hexin-ifind-ds-edb-mcp`;

async function post(payload, sessionId = null, timeout = 30000) {
    const headers = {
        'Content-Type': 'application/json',
        'Accept': 'application/json, text/event-stream',
        'Authorization': AUTH_TOKEN,
    };
    if (sessionId) headers['Mcp-Session-Id'] = sessionId;

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeout);

    try {
        const res = await fetch(SERVER, {
            method: 'POST',
            headers,
            body: JSON.stringify(payload),
            signal: controller.signal,
        });
        clearTimeout(timer);
        const data = await res.json();
        return { res, data, sessionId: res.headers.get('mcp-session-id') };
    } catch (e) {
        clearTimeout(timer);
        throw e;
    }
}

async function main() {
    const initPayload = {
        jsonrpc: "2.0", id: 1, method: "initialize",
        params: { protocolVersion: "2025-03-26", capabilities: {}, clientInfo: { name: "http-client", version: "1.0.0" } },
    };
    const { sessionId } = await post(initPayload, null, 30000);
    if (!sessionId) throw new Error("No session id");
    await post({ jsonrpc: "2.0", method: "notifications/initialized" }, sessionId, 10000);

    // 先搜索北向资金指标
    const searchPayload = {
        jsonrpc: "2.0", id: 2, method: "tools/call",
        params: {
            name: "search_edb",
            arguments: { query: "沪深港通 净流入 北向资金 净买入" },
        },
    };
    const { data: searchData } = await post(searchPayload, sessionId, 30000);
    console.log("SEARCH:", JSON.stringify(searchData, null, 2));
}

main().catch(e => { console.error("Error:", e.message); process.exit(1); });
